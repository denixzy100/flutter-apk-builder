//  Base Kaido Ori By Alip

const fs = require('fs')

global.owner = "6285855060683" //owner number
global.footer = "𝐀𝐥𝐢𝐩" //footer section
global.namabot = "𝐊𝐚𝐢𝐝𝐨" //nama bot
global.status = true //"self/public" section of the bot
global.namaowner = "𝐀𝐥𝐢𝐩"
global.idsaluran = "-"
global.imgmenu = "https://files.cloudkuimages.guru/images/dwh0JIYW.jpg"

//======[ Setting Event ]======//
global.dana = `085855060683`
global.gopay = `085855060683`
global.ovo = "-"
global.shope = "-"
global.bank = "-"
global.qris = fs.readFileSync("./media/qris.jpg")
global.namastore = "`Alip Developer`"
global.lol = "";
global.msg = {
    owner: "Lu Nggak Owner Mbud",
    premium: "Lu Nggak Ada Di DataBase Premium",
    admin: "Lu Nggak Admin tod",
    adminbot: "Jadiin Gw Admin Dulu Dong",
    priv: "khusus gw",
    bot: "khusus buat bot"
}
global.autoTyping = false // ubah jadi true untuk menyalakan auto typing

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
