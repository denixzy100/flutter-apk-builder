module.exports = {
  tokenBot: "TOKEN_LO",
  ownerID: "ID_LO",
};
