import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../models/saving.dart';

const _kSavingsKey = 'celengan_savings_v1';
const _uuid = Uuid();

class SavingsProvider extends ChangeNotifier {
  List<Saving> _savings = [];
  bool _loaded = false;

  List<Saving> get savings => List.unmodifiable(_savings);
  bool get loaded => _loaded;

  double get totalSaved => _savings.fold(0, (sum, s) => sum + s.currentAmount);
  double get totalTarget => _savings.fold(0, (sum, s) => sum + s.targetAmount);
  int get completedCount => _savings.where((s) => s.isCompleted).length;
  int get activeCount => _savings.where((s) => !s.isCompleted).length;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kSavingsKey);
    if (raw != null) {
      final list = jsonDecode(raw) as List<dynamic>;
      _savings = list.map((e) => Saving.fromJson(e as Map<String, dynamic>)).toList();
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = jsonEncode(_savings.map((s) => s.toJson()).toList());
    await prefs.setString(_kSavingsKey, encoded);
  }

  Future<void> addSaving({
    required String name,
    required double targetAmount,
    required SavingCategory category,
    DateTime? targetDate,
    required String colorHex,
  }) async {
    final saving = Saving(
      id: _uuid.v4(),
      name: name,
      targetAmount: targetAmount,
      category: category,
      createdAt: DateTime.now(),
      targetDate: targetDate,
      colorHex: colorHex,
    );
    _savings.insert(0, saving);
    await _persist();
    notifyListeners();
  }

  Future<void> deposit(String savingId, double amount, String note) async {
    final idx = _savings.indexWhere((s) => s.id == savingId);
    if (idx == -1) return;
    _savings[idx].currentAmount += amount;
    _savings[idx].transactions.insert(0, Transaction(
      id: _uuid.v4(),
      amount: amount,
      note: note,
      date: DateTime.now(),
      isDeposit: true,
    ));
    await _persist();
    notifyListeners();
  }

  Future<void> withdraw(String savingId, double amount, String note) async {
    final idx = _savings.indexWhere((s) => s.id == savingId);
    if (idx == -1) return;
    final actual = amount.clamp(0, _savings[idx].currentAmount) as double;
    _savings[idx].currentAmount -= actual;
    _savings[idx].transactions.insert(0, Transaction(
      id: _uuid.v4(),
      amount: actual,
      note: note,
      date: DateTime.now(),
      isDeposit: false,
    ));
    await _persist();
    notifyListeners();
  }

  Future<void> deleteSaving(String savingId) async {
    _savings.removeWhere((s) => s.id == savingId);
    await _persist();
    notifyListeners();
  }

  Future<void> updateSaving(Saving updated) async {
    final idx = _savings.indexWhere((s) => s.id == updated.id);
    if (idx == -1) return;
    _savings[idx] = updated;
    await _persist();
    notifyListeners();
  }

  Saving? getById(String id) => _savings.cast<Saving?>().firstWhere(
    (s) => s?.id == id, orElse: () => null,
  );
}
