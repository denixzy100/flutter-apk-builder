import 'package:intl/intl.dart';

final _idr = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);
final _dateShort = DateFormat('d MMM yyyy', 'id_ID');
final _dateFull = DateFormat('EEEE, d MMMM yyyy', 'id_ID');

String formatRupiah(double amount) => _idr.format(amount);
String formatDateShort(DateTime dt) => _dateShort.format(dt);
String formatDateFull(DateTime dt) => _dateFull.format(dt);

String compactRupiah(double amount) {
  if (amount >= 1000000000) return 'Rp ${(amount / 1000000000).toStringAsFixed(1)}M';
  if (amount >= 1000000) return 'Rp ${(amount / 1000000).toStringAsFixed(1)}Jt';
  if (amount >= 1000) return 'Rp ${(amount / 1000).toStringAsFixed(0)}rb';
  return formatRupiah(amount);
}
