import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:provider/provider.dart';
import '../providers/savings_provider.dart';
import '../utils/formatters.dart';
import '../utils/theme.dart';
import '../widgets/saving_card.dart';
import 'add_saving_screen.dart';
import 'detail_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Consumer<SavingsProvider>(
        builder: (context, provider, _) {
          if (!provider.loaded) {
            return const Center(child: CircularProgressIndicator(color: AppTheme.accent));
          }
          return CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              _buildAppBar(context, provider),
              _buildSummaryCards(provider),
              _buildListHeader(context, provider),
              if (provider.savings.isEmpty)
                _buildEmpty(context)
              else
                _buildList(context, provider),
              const SliverToBoxAdapter(child: Gap(100)),
            ],
          );
        },
      ),
      floatingActionButton: _buildFAB(context),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }

  Widget _buildAppBar(BuildContext context, SavingsProvider provider) {
    return SliverAppBar(
      expandedHeight: 0,
      floating: true,
      backgroundColor: AppTheme.bgDark,
      title: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: AppTheme.accentDim,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Center(
              child: Text('🪙', style: TextStyle(fontSize: 18)),
            ),
          ),
          const Gap(10),
          const Text(
            'Celengan Ku',
            style: TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 20,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.bar_chart_rounded, color: AppTheme.textSecondary),
          onPressed: () {},
        ),
      ],
    );
  }

  Widget _buildSummaryCards(SavingsProvider provider) {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
        child: Column(
          children: [
            _TotalCard(provider: provider)
                .animate()
                .fadeIn(duration: 400.ms)
                .slideY(begin: -0.05, end: 0),
            const Gap(12),
            Row(
              children: [
                Expanded(
                  child: _StatCard(
                    label: 'Aktif',
                    value: '${provider.activeCount}',
                    icon: Icons.savings_outlined,
                    color: AppTheme.accent,
                  ),
                ),
                const Gap(10),
                Expanded(
                  child: _StatCard(
                    label: 'Tercapai',
                    value: '${provider.completedCount}',
                    icon: Icons.check_circle_outline_rounded,
                    color: AppTheme.warning,
                  ),
                ),
              ],
            ).animate(delay: 100.ms).fadeIn(duration: 400.ms),
          ],
        ),
      ),
    );
  }

  Widget _buildListHeader(BuildContext context, SavingsProvider provider) {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Tabungan Saya',
              style: TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 17,
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              '${provider.savings.length} celengan',
              style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildList(BuildContext context, SavingsProvider provider) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      sliver: SliverList.builder(
        itemCount: provider.savings.length,
        itemBuilder: (context, i) {
          final saving = provider.savings[i];
          return SavingCard(
            saving: saving,
            index: i,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => DetailScreen(savingId: saving.id)),
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmpty(BuildContext context) {
    return SliverFillRemaining(
      hasScrollBody: false,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('🪣', style: TextStyle(fontSize: 64)),
            const Gap(16),
            const Text(
              'Belum ada celengan',
              style: TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Gap(8),
            const Text(
              'Mulai menabung sekarang,\ntarget impianmu menanti!',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 14),
            ),
          ],
        ).animate().fadeIn(delay: 200.ms, duration: 400.ms),
      ),
    );
  }

  Widget _buildFAB(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: SizedBox(
        width: double.infinity,
        height: 54,
        child: ElevatedButton.icon(
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddSavingScreen()),
          ),
          icon: const Icon(Icons.add_rounded, size: 22),
          label: const Text('Buat Celengan Baru'),
        ),
      ),
    );
  }
}

class _TotalCard extends StatelessWidget {
  final SavingsProvider provider;
  const _TotalCard({required this.provider});

  @override
  Widget build(BuildContext context) {
    final overallProgress = provider.totalTarget > 0
        ? (provider.totalSaved / provider.totalTarget).clamp(0.0, 1.0)
        : 0.0;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF1A2B1E), Color(0xFF161A23)],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.accent.withOpacity(0.2), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Total Tabungan',
            style: TextStyle(color: AppTheme.textSecondary, fontSize: 13),
          ),
          const Gap(6),
          Text(
            formatRupiah(provider.totalSaved),
            style: const TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 32,
              fontWeight: FontWeight.w800,
            ),
          ),
          const Gap(4),
          Text(
            'Target: ${formatRupiah(provider.totalTarget)}',
            style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
          ),
          const Gap(16),
          ClipRRect(
            borderRadius: BorderRadius.circular(100),
            child: LinearProgressIndicator(
              value: overallProgress,
              backgroundColor: AppTheme.accent.withOpacity(0.1),
              valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.accent),
              minHeight: 8,
            ),
          ),
          const Gap(8),
          Text(
            '${(overallProgress * 100).toStringAsFixed(1)}% dari total target',
            style: const TextStyle(color: AppTheme.accent, fontSize: 12, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const Gap(10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: TextStyle(
                  color: color,
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                label,
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
