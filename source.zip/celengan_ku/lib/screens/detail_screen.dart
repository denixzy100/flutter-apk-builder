import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:gap/gap.dart';
import 'package:provider/provider.dart';
import '../models/saving.dart';
import '../providers/savings_provider.dart';
import '../utils/formatters.dart';
import '../utils/theme.dart';

class DetailScreen extends StatelessWidget {
  final String savingId;
  const DetailScreen({super.key, required this.savingId});

  @override
  Widget build(BuildContext context) {
    return Consumer<SavingsProvider>(
      builder: (context, provider, _) {
        final saving = provider.getById(savingId);
        if (saving == null) {
          WidgetsBinding.instance.addPostFrameCallback((_) => Navigator.pop(context));
          return const SizedBox.shrink();
        }
        final cardColor = hexToColor(saving.colorHex);

        return Scaffold(
          appBar: AppBar(
            title: Text(saving.name),
            actions: [
              PopupMenuButton<String>(
                color: AppTheme.bgElevated,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                onSelected: (val) async {
                  if (val == 'delete') {
                    final confirm = await showDialog<bool>(
                      context: context,
                      builder: (_) => AlertDialog(
                        backgroundColor: AppTheme.bgCard,
                        title: const Text('Hapus Celengan?', style: TextStyle(color: AppTheme.textPrimary)),
                        content: Text(
                          'Semua data tabungan "${saving.name}" akan dihapus permanen.',
                          style: const TextStyle(color: AppTheme.textSecondary),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context, false),
                            child: const Text('Batal', style: TextStyle(color: AppTheme.textSecondary)),
                          ),
                          TextButton(
                            onPressed: () => Navigator.pop(context, true),
                            child: const Text('Hapus', style: TextStyle(color: AppTheme.danger)),
                          ),
                        ],
                      ),
                    );
                    if (confirm == true && context.mounted) {
                      await context.read<SavingsProvider>().deleteSaving(savingId);
                      if (context.mounted) Navigator.pop(context);
                    }
                  }
                },
                itemBuilder: (_) => [
                  const PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete_outline_rounded, color: AppTheme.danger, size: 18),
                        Gap(10),
                        Text('Hapus', style: TextStyle(color: AppTheme.danger)),
                      ],
                    ),
                  ),
                ],
                icon: const Icon(Icons.more_vert_rounded, color: AppTheme.textSecondary),
              ),
            ],
          ),
          body: ListView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.all(20),
            children: [
              _buildHeroCard(saving, cardColor).animate().fadeIn(duration: 300.ms).slideY(begin: -0.03),
              const Gap(16),
              _buildActionButtons(context, saving, provider).animate(delay: 100.ms).fadeIn(),
              const Gap(24),
              if (saving.transactions.isNotEmpty) ...[
                const Text(
                  'Riwayat Transaksi',
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const Gap(12),
                ...saving.transactions.take(50).toList().asMap().entries.map((e) =>
                  _TransactionTile(tx: e.value, index: e.key).animate(
                    delay: Duration(milliseconds: 150 + e.key * 40),
                  ).fadeIn().slideX(begin: 0.03),
                ),
              ] else
                _buildEmptyTransactions(),
              const Gap(80),
            ],
          ),
        );
      },
    );
  }

  Widget _buildHeroCard(Saving saving, Color cardColor) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            cardColor.withOpacity(0.15),
            AppTheme.bgCard,
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cardColor.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: cardColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Center(
                  child: Text(saving.category.emoji, style: const TextStyle(fontSize: 26)),
                ),
              ),
              const Gap(14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      saving.name,
                      style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const Gap(2),
                    Text(saving.category.label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                  ],
                ),
              ),
            ],
          ),
          const Gap(24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _InfoChip(label: 'Terkumpul', value: formatRupiah(saving.currentAmount), color: cardColor),
              _InfoChip(label: 'Sisa', value: formatRupiah(saving.remaining), color: AppTheme.textSecondary, isRight: true),
            ],
          ),
          const Gap(16),
          ClipRRect(
            borderRadius: BorderRadius.circular(100),
            child: LinearProgressIndicator(
              value: saving.progress,
              backgroundColor: cardColor.withOpacity(0.12),
              valueColor: AlwaysStoppedAnimation<Color>(cardColor),
              minHeight: 10,
            ),
          ),
          const Gap(10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${saving.progressPercent.toStringAsFixed(1)}%',
                style: TextStyle(color: cardColor, fontSize: 13, fontWeight: FontWeight.w600),
              ),
              Text(
                'Target: ${formatRupiah(saving.targetAmount)}',
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
              ),
            ],
          ),
          if (saving.targetDate != null) ...[
            const Gap(12),
            const Divider(color: AppTheme.bgElevated),
            const Gap(8),
            Row(
              children: [
                const Icon(Icons.calendar_today_outlined, size: 14, color: AppTheme.textSecondary),
                const Gap(6),
                Text(
                  'Target: ${formatDateShort(saving.targetDate!)}',
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                ),
                const Spacer(),
                if (saving.daysLeft != null)
                  Text(
                    saving.daysLeft! >= 0 ? '${saving.daysLeft} hari lagi' : 'Sudah lewat',
                    style: TextStyle(
                      color: saving.daysLeft! >= 0 ? AppTheme.warning : AppTheme.danger,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context, Saving saving, SavingsProvider provider) {
    return Row(
      children: [
        Expanded(
          child: _ActionButton(
            label: 'Top Up',
            icon: Icons.add_rounded,
            color: AppTheme.accent,
            onTap: () => _showTransactionSheet(context, saving, provider, isDeposit: true),
          ),
        ),
        const Gap(12),
        Expanded(
          child: _ActionButton(
            label: 'Tarik',
            icon: Icons.remove_rounded,
            color: AppTheme.danger,
            onTap: saving.currentAmount > 0
                ? () => _showTransactionSheet(context, saving, provider, isDeposit: false)
                : null,
          ),
        ),
      ],
    );
  }

  void _showTransactionSheet(
    BuildContext context,
    Saving saving,
    SavingsProvider provider, {
    required bool isDeposit,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.bgCard,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => _TransactionSheet(
        saving: saving,
        provider: provider,
        isDeposit: isDeposit,
      ),
    );
  }

  Widget _buildEmptyTransactions() {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(16),
      ),
      child: const Column(
        children: [
          Text('📋', style: TextStyle(fontSize: 36)),
          Gap(10),
          Text(
            'Belum ada transaksi',
            style: TextStyle(color: AppTheme.textSecondary),
          ),
        ],
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final bool isRight;

  const _InfoChip({
    required this.label,
    required this.value,
    required this.color,
    this.isRight = false,
  });

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: isRight ? CrossAxisAlignment.end : CrossAxisAlignment.start,
    children: [
      Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
      const Gap(2),
      Text(value, style: TextStyle(color: color, fontSize: 16, fontWeight: FontWeight.w700)),
    ],
  );
}

class _ActionButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;

  const _ActionButton({
    required this.label,
    required this.icon,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedOpacity(
        opacity: onTap == null ? 0.4 : 1.0,
        duration: const Duration(milliseconds: 200),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 20),
              const Gap(6),
              Text(
                label,
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w700,
                  fontSize: 15,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TransactionTile extends StatelessWidget {
  final Transaction tx;
  final int index;

  const _TransactionTile({required this.tx, required this.index});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: (tx.isDeposit ? AppTheme.accent : AppTheme.danger).withOpacity(0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              tx.isDeposit ? Icons.arrow_downward_rounded : Icons.arrow_upward_rounded,
              color: tx.isDeposit ? AppTheme.accent : AppTheme.danger,
              size: 18,
            ),
          ),
          const Gap(12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  tx.note.isEmpty ? (tx.isDeposit ? 'Top Up' : 'Tarik') : tx.note,
                  style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
                ),
                const Gap(2),
                Text(
                  formatDateShort(tx.date),
                  style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                ),
              ],
            ),
          ),
          Text(
            '${tx.isDeposit ? '+' : '-'}${formatRupiah(tx.amount)}',
            style: TextStyle(
              color: tx.isDeposit ? AppTheme.accent : AppTheme.danger,
              fontWeight: FontWeight.w700,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}

class _TransactionSheet extends StatefulWidget {
  final Saving saving;
  final SavingsProvider provider;
  final bool isDeposit;

  const _TransactionSheet({
    required this.saving,
    required this.provider,
    required this.isDeposit,
  });

  @override
  State<_TransactionSheet> createState() => _TransactionSheetState();
}

class _TransactionSheetState extends State<_TransactionSheet> {
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  bool _loading = false;

  @override
  void dispose() {
    _amountCtrl.dispose();
    _noteCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final amountStr = _amountCtrl.text.replaceAll(RegExp(r'[^0-9]'), '');
    final amount = double.tryParse(amountStr) ?? 0;
    if (amount <= 0) return;

    setState(() => _loading = true);
    if (widget.isDeposit) {
      await widget.provider.deposit(widget.saving.id, amount, _noteCtrl.text.trim());
    } else {
      await widget.provider.withdraw(widget.saving.id, amount, _noteCtrl.text.trim());
    }
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.isDeposit ? AppTheme.accent : AppTheme.danger;
    return Padding(
      padding: EdgeInsets.only(
        left: 20, right: 20, top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 4,
                height: 24,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const Gap(10),
              Text(
                widget.isDeposit ? 'Top Up Tabungan' : 'Tarik Tabungan',
                style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const Gap(20),
          TextFormField(
            controller: _amountCtrl,
            autofocus: true,
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 24, fontWeight: FontWeight.w700),
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: InputDecoration(
              hintText: '0',
              hintStyle: const TextStyle(color: AppTheme.textMuted, fontSize: 24, fontWeight: FontWeight.w700),
              prefixText: 'Rp ',
              prefixStyle: TextStyle(color: color, fontSize: 24, fontWeight: FontWeight.w700),
              border: InputBorder.none,
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
              filled: false,
            ),
          ),
          const Divider(color: AppTheme.bgElevated),
          const Gap(12),
          TextFormField(
            controller: _noteCtrl,
            style: const TextStyle(color: AppTheme.textPrimary),
            decoration: const InputDecoration(
              hintText: 'Catatan (opsional)',
              prefixIcon: Icon(Icons.notes_rounded, color: AppTheme.textSecondary),
            ),
          ),
          const Gap(20),
          SizedBox(
            width: double.infinity,
            height: 52,
            child: ElevatedButton(
              onPressed: _loading ? null : _submit,
              style: ElevatedButton.styleFrom(
                backgroundColor: color,
                foregroundColor: color == AppTheme.accent ? AppTheme.bgDark : Colors.white,
              ),
              child: _loading
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Text(widget.isDeposit ? 'Simpan' : 'Tarik'),
            ),
          ),
        ],
      ),
    );
  }
}
