import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gap/gap.dart';
import 'package:provider/provider.dart';
import '../models/saving.dart';
import '../providers/savings_provider.dart';
import '../utils/formatters.dart';
import '../utils/theme.dart';

class AddSavingScreen extends StatefulWidget {
  const AddSavingScreen({super.key});

  @override
  State<AddSavingScreen> createState() => _AddSavingScreenState();
}

class _AddSavingScreenState extends State<AddSavingScreen> {
  final _nameCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  SavingCategory _category = SavingCategory.umum;
  DateTime? _targetDate;
  String _selectedColor = AppTheme.cardColors[0];
  bool _saving = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _amountCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 30)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
      builder: (context, child) => Theme(
        data: AppTheme.theme.copyWith(
          colorScheme: const ColorScheme.dark(
            primary: AppTheme.accent,
            surface: AppTheme.bgCard,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _targetDate = picked);
  }

  Future<void> _submit() async {
    final name = _nameCtrl.text.trim();
    final amountStr = _amountCtrl.text.replaceAll(RegExp(r'[^0-9]'), '');
    final amount = double.tryParse(amountStr) ?? 0;

    if (name.isEmpty) {
      _showError('Nama celengan wajib diisi');
      return;
    }
    if (amount <= 0) {
      _showError('Target amount wajib diisi');
      return;
    }

    setState(() => _saving = true);
    await context.read<SavingsProvider>().addSaving(
      name: name,
      targetAmount: amount,
      category: _category,
      targetDate: _targetDate,
      colorHex: _selectedColor,
    );
    if (mounted) Navigator.pop(context);
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: AppTheme.danger,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Celengan Baru'),
        leading: IconButton(
          icon: const Icon(Icons.close_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _SectionLabel('Nama Celengan'),
          const Gap(8),
          TextFormField(
            controller: _nameCtrl,
            style: const TextStyle(color: AppTheme.textPrimary),
            decoration: const InputDecoration(
              hintText: 'cth: Liburan Bali 2025',
              prefixIcon: Icon(Icons.savings_outlined, color: AppTheme.textSecondary),
            ),
            textCapitalization: TextCapitalization.words,
          ),
          const Gap(20),
          _SectionLabel('Target Tabungan'),
          const Gap(8),
          TextFormField(
            controller: _amountCtrl,
            style: const TextStyle(color: AppTheme.textPrimary),
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(
              hintText: '5000000',
              prefixIcon: Icon(Icons.attach_money_rounded, color: AppTheme.textSecondary),
              prefixText: 'Rp ',
              prefixStyle: TextStyle(color: AppTheme.textSecondary),
            ),
          ),
          const Gap(20),
          _SectionLabel('Kategori'),
          const Gap(10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: SavingCategory.values.map((cat) {
              final selected = _category == cat;
              return GestureDetector(
                onTap: () => setState(() => _category = cat),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: selected ? AppTheme.accentDim : AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(100),
                    border: Border.all(
                      color: selected ? AppTheme.accent : AppTheme.textMuted.withOpacity(0.3),
                    ),
                  ),
                  child: Text(
                    '${cat.emoji} ${cat.label}',
                    style: TextStyle(
                      color: selected ? AppTheme.accent : AppTheme.textSecondary,
                      fontSize: 13,
                      fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const Gap(20),
          _SectionLabel('Warna'),
          const Gap(10),
          Row(
            children: AppTheme.cardColors.map((hex) {
              final color = hexToColor(hex);
              final selected = _selectedColor == hex;
              return GestureDetector(
                onTap: () => setState(() => _selectedColor = hex),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  margin: const EdgeInsets.only(right: 10),
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: selected ? Colors.white : Colors.transparent,
                      width: 2.5,
                    ),
                    boxShadow: selected
                        ? [BoxShadow(color: color.withOpacity(0.5), blurRadius: 8)]
                        : [],
                  ),
                  child: selected
                      ? const Icon(Icons.check_rounded, color: Colors.black, size: 16)
                      : null,
                ),
              );
            }).toList(),
          ),
          const Gap(20),
          _SectionLabel('Target Waktu (Opsional)'),
          const Gap(8),
          GestureDetector(
            onTap: _pickDate,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: AppTheme.bgElevated,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.textMuted.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.calendar_today_outlined, color: AppTheme.textSecondary, size: 20),
                  const Gap(12),
                  Text(
                    _targetDate != null
                        ? formatDateShort(_targetDate!)
                        : 'Pilih tanggal target',
                    style: TextStyle(
                      color: _targetDate != null ? AppTheme.textPrimary : AppTheme.textMuted,
                    ),
                  ),
                  const Spacer(),
                  if (_targetDate != null)
                    GestureDetector(
                      onTap: () => setState(() => _targetDate = null),
                      child: const Icon(Icons.close_rounded, color: AppTheme.textSecondary, size: 18),
                    ),
                ],
              ),
            ),
          ),
          const Gap(32),
          ElevatedButton(
            onPressed: _saving ? null : _submit,
            child: _saving
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppTheme.bgDark,
                    ),
                  )
                : const Text('Buat Celengan'),
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) => Text(
    text,
    style: const TextStyle(
      color: AppTheme.textSecondary,
      fontSize: 13,
      fontWeight: FontWeight.w500,
    ),
  );
}
