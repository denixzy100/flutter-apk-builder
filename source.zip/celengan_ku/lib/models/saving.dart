import 'dart:convert';

enum SavingCategory {
  umum,
  liburan,
  gadget,
  pendidikan,
  darurat,
  kendaraan,
  rumah,
  lainnya,
}

extension SavingCategoryExt on SavingCategory {
  String get label {
    switch (this) {
      case SavingCategory.umum: return 'Umum';
      case SavingCategory.liburan: return 'Liburan';
      case SavingCategory.gadget: return 'Gadget';
      case SavingCategory.pendidikan: return 'Pendidikan';
      case SavingCategory.darurat: return 'Dana Darurat';
      case SavingCategory.kendaraan: return 'Kendaraan';
      case SavingCategory.rumah: return 'Rumah';
      case SavingCategory.lainnya: return 'Lainnya';
    }
  }

  String get emoji {
    switch (this) {
      case SavingCategory.umum: return '💰';
      case SavingCategory.liburan: return '✈️';
      case SavingCategory.gadget: return '📱';
      case SavingCategory.pendidikan: return '📚';
      case SavingCategory.darurat: return '🛡️';
      case SavingCategory.kendaraan: return '🚗';
      case SavingCategory.rumah: return '🏠';
      case SavingCategory.lainnya: return '🎯';
    }
  }
}

class Transaction {
  final String id;
  final double amount;
  final String note;
  final DateTime date;
  final bool isDeposit;

  Transaction({
    required this.id,
    required this.amount,
    required this.note,
    required this.date,
    required this.isDeposit,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'amount': amount,
    'note': note,
    'date': date.toIso8601String(),
    'isDeposit': isDeposit,
  };

  factory Transaction.fromJson(Map<String, dynamic> json) => Transaction(
    id: json['id'],
    amount: (json['amount'] as num).toDouble(),
    note: json['note'],
    date: DateTime.parse(json['date']),
    isDeposit: json['isDeposit'],
  );
}

class Saving {
  final String id;
  String name;
  double targetAmount;
  double currentAmount;
  SavingCategory category;
  DateTime createdAt;
  DateTime? targetDate;
  String colorHex;
  List<Transaction> transactions;

  Saving({
    required this.id,
    required this.name,
    required this.targetAmount,
    this.currentAmount = 0,
    required this.category,
    required this.createdAt,
    this.targetDate,
    required this.colorHex,
    List<Transaction>? transactions,
  }) : transactions = transactions ?? [];

  double get progress => targetAmount > 0 ? (currentAmount / targetAmount).clamp(0.0, 1.0) : 0;
  double get progressPercent => progress * 100;
  double get remaining => (targetAmount - currentAmount).clamp(0, double.infinity);
  bool get isCompleted => currentAmount >= targetAmount;

  int? get daysLeft {
    if (targetDate == null) return null;
    return targetDate!.difference(DateTime.now()).inDays;
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'targetAmount': targetAmount,
    'currentAmount': currentAmount,
    'category': category.index,
    'createdAt': createdAt.toIso8601String(),
    'targetDate': targetDate?.toIso8601String(),
    'colorHex': colorHex,
    'transactions': transactions.map((t) => t.toJson()).toList(),
  };

  factory Saving.fromJson(Map<String, dynamic> json) => Saving(
    id: json['id'],
    name: json['name'],
    targetAmount: (json['targetAmount'] as num).toDouble(),
    currentAmount: (json['currentAmount'] as num).toDouble(),
    category: SavingCategory.values[json['category'] as int],
    createdAt: DateTime.parse(json['createdAt']),
    targetDate: json['targetDate'] != null ? DateTime.parse(json['targetDate']) : null,
    colorHex: json['colorHex'],
    transactions: (json['transactions'] as List<dynamic>?)
        ?.map((t) => Transaction.fromJson(t as Map<String, dynamic>))
        .toList() ?? [],
  );
}
