# 🪙 Celengan Ku

Aplikasi tabungan modern dengan UI gelap — Flutter, offline-first, siap build.

## Fitur
- Buat banyak celengan dengan kategori & warna sendiri
- Target amount + target tanggal
- Top up & tarik dengan catatan
- Riwayat transaksi per celengan
- Dashboard total tabungan semua celengan
- Persistent storage (SharedPreferences, no internet needed)
- Animasi smooth dengan flutter_animate

## Stack
- Flutter ≥3.0 / Dart ≥3.0
- provider ^6.1.1 — state management
- shared_preferences ^2.2.2 — local storage
- google_fonts — Plus Jakarta Sans
- flutter_animate — micro animations
- fl_chart — (siap dipakai untuk grafik)
- intl — format Rupiah & tanggal Indonesia
- uuid ^4.3.3
- gap ^3.0.1

## Build di CodeAssist / Terminal

```bash
# 1. Pastikan Flutter SDK aktif
flutter --version

# 2. Install dependencies
flutter pub get

# 3. Build debug APK
flutter build apk --debug

# 4. Build release APK (unsigned, langsung pakai)
flutter build apk --release

# APK output:
# build/app/outputs/flutter-apk/app-debug.apk
# build/app/outputs/flutter-apk/app-release.apk
```

## Struktur
```
lib/
├── main.dart
├── models/saving.dart        # Saving + Transaction model
├── providers/
│   └── savings_provider.dart # State + persistence
├── screens/
│   ├── home_screen.dart      # Dashboard utama
│   ├── add_saving_screen.dart# Form buat celengan
│   └── detail_screen.dart    # Detail + top up + tarik
├── widgets/
│   └── saving_card.dart      # Card komponen
└── utils/
    ├── theme.dart             # Dark theme + warna
    └── formatters.dart        # Rupiah + tanggal
```
