module.exports = {
  Xata_TOKEN: "TOKEN",
  OWNER_ID: ["IDS"],
};